export class UnidadMedida {
  idUnidad: number
  nombre: string
}
